﻿using System;

namespace CustomDoublyLinkedList
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
